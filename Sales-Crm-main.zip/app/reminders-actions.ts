'use server'

import { createSupabaseServer, getCurrentUser, getCurrentProfile } from '../lib/supabase-server'

export type Reminder = {
  id: string
  companyId: string | null
  practiceCode: string | null
  practiceName: string
  remindAt: string
  note: string | null
  done: boolean
  completedAt: string | null
  // Shown whenever the view spans more than just the caller's own reminders.
  agentName: string | null
  // Shown for Super Admin only, since that's the only view spanning companies.
  companyName: string | null
  practiceDeleted: boolean
}

type ReminderRow = {
  id: string
  practice_id: string
  tenant_id: string | null
  agent_id: string
  remind_at: string
  note: string | null
  done: boolean
  completed_at: string | null
  master_practices: { practice_code: string; name: string } | null
  users: { full_name: string } | null
  tenants: { name: string } | null
}

type ReminderAccessRow = { id: string; agent_id: string; tenant_id: string | null }

async function whoAmI() {
  const { data: { user } } = await getCurrentUser()
  if (!user) return null
  const { data: me } = await getCurrentProfile(user.id)
  if (!me) return null
  return {
    id: me.id,
    tenantId: me.tenant_id,
    roleKey: me.roles?.key ?? '',
  }
}

// Returns reminders in scope for the caller:
//   super_admin: every company's reminders
//   company_admin / manager / team_lead: their own company's reminders (every agent/closer)
//   agent / closer: only reminders they personally set
export async function getReminders(): Promise<{
  ok: boolean; message?: string; reminders?: Reminder[]; scope?: 'all' | 'company' | 'mine'
}> {
  return readReminders(false)
}

// ← ADDED: only reminders that are not done yet — all the notification bell
// needs. The bell loads on every page, and the full list (with every
// completed reminder ever) grows forever; this keeps that request small.
export async function getActiveReminders(): Promise<{
  ok: boolean; message?: string; reminders?: Reminder[]; scope?: 'all' | 'company' | 'mine'
}> {
  return readReminders(true)
}

async function readReminders(activeOnly: boolean): Promise<{ // ← CHANGED: shared by both
  ok: boolean; message?: string; reminders?: Reminder[]; scope?: 'all' | 'company' | 'mine'
}> {
  const supabase = await createSupabaseServer()
  const me = await whoAmI()
  if (!me) return { ok: false, message: 'Not signed in.' }

  const isSuperAdmin = me.roleKey === 'super_admin'
  const isCompanyRole = ['company_admin', 'manager', 'team_lead'].includes(me.roleKey)
  const scope: 'all' | 'company' | 'mine' = isSuperAdmin ? 'all' : isCompanyRole ? 'company' : 'mine'

  const readRows = (includeCompletedAt: boolean) => {
    let q = supabase
      .from('lead_reminders')
      .select(`id, practice_id, tenant_id, agent_id, remind_at, note, done, ${includeCompletedAt ? 'completed_at,' : ''} master_practices(practice_code, name), users(full_name), tenants(name)`)
      .order('remind_at', { ascending: true })
    if (scope === 'company') q = q.eq('tenant_id', me.tenantId)
    else if (scope === 'mine') q = q.eq('agent_id', me.id)
    if (activeOnly) q = q.or('done.is.null,done.eq.false') // ← ADDED
    return q
  }

  let { data: rows, error } = await readRows(true)
  // Safe rollout fallback: existing databases keep working until the additive
  // completed_at migration is applied.
  if (error?.code === '42703') ({ data: rows, error } = await readRows(false))
  if (error) return { ok: false, message: error.message }
  if (!rows || rows.length === 0) return { ok: true, reminders: [], scope }

  const reminders: Reminder[] = (rows as unknown as ReminderRow[]).map((r) => {
    const p = r.master_practices
    return {
      id: r.id,
      companyId: r.tenant_id ?? null,
      practiceCode: p?.practice_code ?? null,
      practiceName: p?.name ?? '(deleted lead)',
      remindAt: r.remind_at,
      note: r.note ?? null,
      done: !!r.done,
      completedAt: r.completed_at ?? null,
      agentName: scope !== 'mine' ? (r.users?.full_name ?? null) : null,
      companyName: isSuperAdmin ? (r.tenants?.name ?? null) : null,
      practiceDeleted: !p,
    }
  })

  return { ok: true, reminders, scope }
}

// Marks a reminder done. Allowed for the agent who set it, their company's
// management (company_admin/manager/team_lead), or Super Admin — matches the
// same "who can see it" scope, since anyone who can see a reminder in an
// oversight view should also be able to clear a stale one.
export async function markReminderDone(reminderId: string): Promise<{ ok: boolean; message?: string; completedAt?: string }> {
  const supabase = await createSupabaseServer()
  const me = await whoAmI()
  if (!me) return { ok: false, message: 'Not signed in.' }

  const { data: reminder } = await supabase
    .from('lead_reminders')
    .select('id, agent_id, tenant_id')
    .eq('id', reminderId)
    .maybeSingle()
  if (!reminder) return { ok: false, message: 'This reminder no longer exists.' }

  const isSuperAdmin = me.roleKey === 'super_admin'
  const isCompanyRole = ['company_admin', 'manager', 'team_lead'].includes(me.roleKey)
  const access = reminder as ReminderAccessRow
  const isMine = access.agent_id === me.id
  const isMyCompany = isCompanyRole && access.tenant_id === me.tenantId
  if (!isSuperAdmin && !isMine && !isMyCompany) {
    return { ok: false, message: 'Not allowed.' }
  }

  const completedAt = new Date().toISOString()
  let { error } = await supabase.from('lead_reminders').update({ done: true, completed_at: completedAt }).eq('id', reminderId)
  if (error?.code === '42703') ({ error } = await supabase.from('lead_reminders').update({ done: true }).eq('id', reminderId))
  if (error) return { ok: false, message: error.message }
  return { ok: true, completedAt }
}

