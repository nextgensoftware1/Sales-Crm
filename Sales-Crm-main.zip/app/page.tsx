import { createSupabaseServer } from '../lib/supabase-server'
import { roleLabel } from '../lib/roles'
import PracticesTable from './PracticesTable'
import UploadLeadsButton from './UploadLeadsButton'
import { redirect } from 'next/navigation'
import AppShell from './AppShell'

export default async function Home() {
  const supabase = await createSupabaseServer()

  const { data: { user } } = await supabase.auth.getUser()
  if (!user) redirect('/login')

  const { data: me } = await supabase
    .from('users')
    .select('id, full_name, tenant_id, roles(key, label, level), tenants(name)')
    .eq('auth_id', user.id)
    .single()

  const roleKey = (me as any)?.roles?.key ?? ''
  const isSuperAdmin = roleKey === 'super_admin'
  const canUpload = ['company_admin', 'manager', 'super_admin'].includes(roleKey)
  const canAssign = ['company_admin', 'manager', 'team_lead'].includes(roleKey)
  const showTransfers = true
  const canManageUsers = isSuperAdmin || canAssign
  const myTenantId = (me as any)?.tenant_id
  const myUserId = (me as any)?.id

  let myAgents: { id: string; full_name: string; role: string }[] = []
  if (canAssign) {
    const myLevel = (me as any)?.roles?.level ?? 999
    const { data: agentRows } = await supabase
      .from('users')
      .select('id, full_name, roles(key, label, level)')
      .eq('tenant_id', myTenantId)
      .order('full_name')
    myAgents = (agentRows ?? [])
      .filter((u: any) => (u.roles?.level ?? 0) > myLevel)
      .map((u: any) => ({ id: u.id, full_name: u.full_name, role: roleLabel(u.roles?.key) }))
  }

  let companies: { slug: string; name: string }[] = []
  if (isSuperAdmin) {
    const { data: tenantRows } = await supabase
      .from('tenants')
      .select('slug, name, is_platform')
      .eq('is_platform', false)
      .order('name')
    companies = (tenantRows ?? []).map((t: any) => ({ slug: t.slug, name: t.name }))
  }

  const currentUser = me
    ? {
        full_name: me.full_name,
        role: roleLabel((me as any).roles?.key),
        company: (me as any).tenants?.name ?? 'Unknown',
      }
    : null

  const allocatedOn: Record<string, string> = {}
  const leadStatus: Record<string, string> = {}
  let assignedIds: string[] | null = null
  if (roleKey === 'agent' || roleKey === 'closer' || roleKey === 'manager' || roleKey === 'team_lead') {
    const idSet = new Set<string>()

    const { data: assigns } = await supabase
      .from('lead_assignments')
      .select('practice_id, assigned_at, current_status')
      .eq('assigned_to', myUserId)
      .eq('status', 'active')
    for (const a of (assigns ?? []) as any[]) {
      if (a.practice_id) {
        idSet.add(a.practice_id)
        allocatedOn[a.practice_id] = a.assigned_at
        leadStatus[a.practice_id] = a.current_status ?? ''
      }
    }

    if (roleKey === 'closer') {
      const { data: transfers } = await supabase
        .from('lead_transfers')
        .select('practice_id, created_at')
        .eq('to_user_id', myUserId)
      for (const t of (transfers ?? []) as any[]) {
        if (t.practice_id) {
          idSet.add(t.practice_id)
          if (!allocatedOn[t.practice_id]) allocatedOn[t.practice_id] = t.created_at
          if (!leadStatus[t.practice_id]) leadStatus[t.practice_id] = 'Transferred'
        }
      }
    }

    assignedIds = Array.from(idSet)
  }

  let myAssignedCodes: string[] = []
  const assignedAwayTo: Record<string, { name: string; role: string }> = {}
  if (canAssign) {
    const { data: mine } = await supabase
      .from('lead_assignments')
      .select('practice_id, master_practices(practice_code)')
      .eq('assigned_to', myUserId)
      .eq('status', 'active')
    myAssignedCodes = (mine ?? [])
      .map((r: any) => r.master_practices?.practice_code)
      .filter(Boolean)

    const { data: away } = await supabase
      .from('lead_assignments')
      .select('practice_id, users!lead_assignments_assigned_to_fkey(full_name, roles(key, label))')
      .eq('assigned_by', myUserId)
      .eq('status', 'active')
    for (const r of (away ?? []) as any[]) {
      if (r.practice_id && r.users) {
        assignedAwayTo[r.practice_id] = {
          name: r.users.full_name,
          role: roleLabel(r.users.roles?.key),
        }
      }
    }
  }

  let myAllocatedIds: string[] = []
  if (!isSuperAdmin && myTenantId) {
    const { data: allocs } = await supabase
      .from('lead_allocations')
      .select('practice_id')
      .eq('tenant_id', myTenantId)
      .eq('status', 'active')
    myAllocatedIds = (allocs ?? [])
      .map((a: any) => a.practice_id)
      .filter((id: any) => typeof id === 'string' && id.length > 0)
  }

  const allocatedCodeSet = new Set<string>()
  const allocatedCompanyByCode: Record<string, string> = {}
  {
    let aq = supabase
      .from('lead_allocations')
      .select('tenant_id, master_practices(practice_code), tenants(name)')
      .eq('status', 'active')
    if (!isSuperAdmin && myTenantId) aq = aq.eq('tenant_id', myTenantId)
    const { data: allocAll } = await aq
    for (const a of (allocAll ?? []) as any[]) {
      const code = a.master_practices?.practice_code
      if (code) {
        allocatedCodeSet.add(code)
        if (isSuperAdmin && a.tenants?.name) allocatedCompanyByCode[code] = a.tenants.name
      }
    }
  }

  let engagedElsewhere = new Set<string>()
  if (!isSuperAdmin && myTenantId) {
    const { data: engaged } = await supabase
      .from('lead_assignments')
      .select('practice_id, tenant_id')
      .eq('status', 'active')
    for (const a of (engaged ?? []) as any[]) {
      if (a.tenant_id && a.tenant_id !== myTenantId) engagedElsewhere.add(a.practice_id)
    }
  }

  const SELECT = `
    id, practice_code, name, state, specialty, owner_tenant_id, created_at,
    practice_providers (
      providers (
        npi, org_name, nppes_sex, nppes_last_updated, payment_adj_pct, at_risk,
        provider_signals ( ccm, pcm, awv, tcm, bhi, rpm, rcm_fit ),
        provider_mips ( performance_year, status, reporting_option )
      )
    )
  `
  const PAGE = 1000
  const CHUNK_IDS = 300

  const fetchAllPaged = async (makeQuery: () => any) => {
    const out: any[] = []
    let from = 0
    while (true) {
      const { data: batch, error: err } = await makeQuery().range(from, from + PAGE - 1)
      if (err) throw err
      if (!batch || batch.length === 0) break
      out.push(...batch)
      if (batch.length < PAGE) break
      from += PAGE
    }
    return out
  }

  const fetchByIds = async (idsIn: string[]) => {
    const ids = (idsIn ?? []).filter((id) => typeof id === 'string' && id.length > 0)
    if (ids.length === 0) return []
    const chunks: string[][] = []
    for (let i = 0; i < ids.length; i += CHUNK_IDS) chunks.push(ids.slice(i, i + CHUNK_IDS))
    const results = await Promise.all(
      chunks.map((chunk) =>
        fetchAllPaged(() =>
          supabase.from('master_practices').select(SELECT).in('id', chunk).eq('is_roster', false).order('name')
        )
      )
    )
    return results.flat()
  }

  let data: any[] = []
  let error: any = null
  try {
    if (isSuperAdmin) {
      // All ANCHOR practices EXCEPT soft-deleted (roster members hidden).
      data = await fetchAllPaged(() =>
        supabase.from('master_practices').select(SELECT)
          .is('deleted_at', null)
          .eq('is_roster', false)
          .order('name')
      )
    } else if (roleKey === 'agent' || roleKey === 'closer' || roleKey === 'manager' || roleKey === 'team_lead') {
      data = await fetchByIds(assignedIds ?? [])
    } else {
      // Company Admin only: OWNED + ALLOCATED — anchors only, roster hidden.
      const [owned, allocated] = await Promise.all([
        fetchAllPaged(() =>
          supabase.from('master_practices').select(SELECT).eq('owner_tenant_id', myTenantId).eq('is_roster', false).order('name')
        ),
        fetchByIds(myAllocatedIds),
      ])
      data = [...owned, ...allocated]
    }
  } catch (e: any) {
    error = e
  }

  if (error) {
    return (
      <div style={{ padding: 40 }}>
        <h1 style={{ color: 'red' }}>Error loading practices</h1>
        <pre style={{ whiteSpace: 'pre-wrap', color: '#f66' }}>{JSON.stringify({
          message: error?.message,
          details: error?.details,
          hint: error?.hint,
          code: error?.code,
        }, null, 2)}</pre>
      </div>
    )
  }

  const isAgentOrCloser = roleKey === 'agent' || roleKey === 'closer'
  const isCompanyAdmin = roleKey === 'company_admin'
  if (!isSuperAdmin && !isAgentOrCloser && !isCompanyAdmin) {
    if (engagedElsewhere.size) {
      data = data.filter((p: any) => !engagedElsewhere.has(p.id))
    }
  }

  const seen = new Set<string>()
  data = data.filter((p: any) => {
    if (seen.has(p.practice_code)) return false
    seen.add(p.practice_code)
    return true
  })

  const lastDialed: Record<string, string> = {}
  const workedPracticeIds = new Set<string>()
  {
    const pids = data.map((p: any) => p.id)
    for (let i = 0; i < pids.length; i += 300) {
      const part = pids.slice(i, i + 300)
      const { data: acts } = await supabase
        .from('lead_activity')
        .select('practice_id, created_at')
        .in('practice_id', part)
        .order('created_at', { ascending: false })
      for (const a of (acts ?? []) as any[]) {
        if (a.practice_id) {
          workedPracticeIds.add(a.practice_id)
          if (!lastDialed[a.practice_id]) lastDialed[a.practice_id] = a.created_at
        }
      }
    }
  }

  const newLeadCodes = new Set<string>()
  const workedLeadCodes = new Set<string>()
  {
    const timestamps = data
      .map((p: any) => p.created_at)
      .filter(Boolean)
      .map((s: string) => new Date(s).getTime())
    if (timestamps.length) {
      const maxT = Math.max(...timestamps)
      const windowMs = 5 * 60 * 1000
      for (const p of data) {
        if (p.created_at) {
          const t = new Date(p.created_at).getTime()
          if (maxT - t <= windowMs) newLeadCodes.add(p.practice_code)
        }
        if (workedPracticeIds.has(p.id)) workedLeadCodes.add(p.practice_code)
      }
    } else {
      for (const p of data) {
        if (workedPracticeIds.has(p.id)) workedLeadCodes.add(p.practice_code)
      }
    }
  }

  const practices = data.map((p: any) => {
    const provider = p.practice_providers?.[0]?.providers
    const s = provider?.provider_signals ?? {}
    const mipsRows = Array.isArray(provider?.provider_mips) ? provider.provider_mips : []
    const mipsByYear: Record<number, string> = {}
    for (const m of mipsRows) {
      const raw = (m.reporting_option ?? m.status ?? '').toString().trim()
      let year = m.performance_year
      if (!year) {
        const match = raw.match(/^(\d{4})/)
        if (match) year = parseInt(match[1], 10)
      }
      if (year) {
        const statusText = raw.replace(/^\d{4}\s*-\s*/, '')
        mipsByYear[year] = statusText || raw
      }
    }

    return {
      practiceCode: p.practice_code,
      allocatedOn: allocatedOn[p.id] ?? null,
      status: leadStatus[p.id] ?? null,
      assignedAwayTo: assignedAwayTo[p.id] ?? null,
      source: allocatedCodeSet.has(p.practice_code) ? 'Allocated' : 'Uploaded',
      allocatedTo: allocatedCompanyByCode[p.practice_code] ?? null,
      name: p.name,
      state: p.state,
      specialty: p.specialty,
      sex: provider?.nppes_sex ?? null,
      orgName: provider?.org_name ?? null,
      risk: provider?.at_risk ?? null,
      paymentAdj: provider?.payment_adj_pct ?? null,
      lastDialed: lastDialed[p.id] ?? null,
      ccm: s.ccm ?? false,
      pcm: s.pcm ?? false,
      awv: s.awv ?? false,
      tcm: s.tcm ?? false,
      bhi: s.bhi ?? false,
      rpm: s.rpm ?? false,
      rcmFit: s.rcm_fit ?? false,
      mips: mipsByYear,
      mipsByYear,
    }
  })

  return (
    <AppShell
      title="Leads Management Engine"
      subtitle="Import, deduplicate, and assign practice-first leads to employees"
      currentUser={currentUser}
      active="/"
      showAdmin={isSuperAdmin}
      showTransfers={showTransfers}
      canManageUsers={canManageUsers}
      headerRight={canUpload ? <UploadLeadsButton /> : null}
    >
      <PracticesTable
        practices={practices}
        currentUser={currentUser}
        isSuperAdmin={isSuperAdmin}
        companies={companies}
        canAssign={canAssign}
        myAgents={myAgents}
        myAssignedCodes={myAssignedCodes}
        newLeadCodes={Array.from(newLeadCodes)}
        workedLeadCodes={Array.from(workedLeadCodes)}
      />
    </AppShell>
  )
}