import { createSupabaseServer, getCurrentUser, getCurrentProfile } from '../../lib/supabase-server'
import { roleLabel as canonicalRoleLabel } from '../../lib/roles'
import { redirect } from 'next/navigation'
import { readAllPages } from '../../lib/query-utils'
import { rangeBounds } from '../../lib/date-range'
import DashboardView from './DashboardView'

// First/last day of the current month, as YYYY-MM-DD — the picker's
// default range when no ?from=&to= is in the URL yet.
function currentMonthRange(): { from: string; to: string } {
  const now = new Date()
  const first = new Date(now.getFullYear(), now.getMonth(), 1)
  const last = new Date(now.getFullYear(), now.getMonth() + 1, 0)
  return { from: first.toISOString().slice(0, 10), to: last.toISOString().slice(0, 10) }
}

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string; to?: string; company?: string; agent?: string }>
}) {
  const supabase = await createSupabaseServer()

  const { data: { user } } = await getCurrentUser()
  if (!user) redirect('/login')

  const { data: me } = await getCurrentProfile(user.id)

  const roleKey = (me as any)?.roles?.key ?? ''
  const isSuperAdmin = roleKey === 'super_admin'
  const isAgentOrCloser = roleKey === 'agent' || roleKey === 'closer'
  const canManageAssignments = ['company_admin', 'manager', 'team_lead'].includes(roleKey)
  const myTenantId = (me as any)?.tenant_id
  const myUserId = (me as any)?.id

  const sp = await searchParams
  // from/to are plain dates (older links, the default month) or exact moments
  // chosen with the date + time picker. Anything invalid falls back to this month.
  const defaults = currentMonthRange()
  const requested = rangeBounds(sp.from, sp.to)
  const fromDate = requested ? (sp.from as string) : defaults.from
  const toDate = requested ? (sp.to as string) : defaults.to
  const { fromISO, toISO } = requested ?? rangeBounds(defaults.from, defaults.to)!

  // ---- Dashboard-wide Company / Agent filters (apply to every number) ----
  // Company: Super Admin only. Agent: Super Admin (within the chosen company)
  // and company admins / managers / team leads (own company only). Agents and
  // closers always see just their own work.
  const isUuid = (v: unknown): v is string => typeof v === 'string' && /^[0-9a-f-]{36}$/i.test(v)
  const { data: companyRows } = isSuperAdmin
    ? await supabase.from('tenants').select('id, name').eq('is_platform', false).order('name')
    : { data: null }
  const companies = ((companyRows ?? []) as { id: string; name: string }[])
  const companyFilter = isSuperAdmin && isUuid(sp.company) && companies.some((c) => c.id === sp.company) ? sp.company : ''
  const peopleTenant = isSuperAdmin ? companyFilter || null : isAgentOrCloser ? null : myTenantId
  const { data: peopleRows } = peopleTenant
    // ← CHANGED: deleted (suspended) users are not offered in the Agent dropdown
    ? await supabase.from('users').select('id, full_name').eq('tenant_id', peopleTenant).eq('status', 'active').order('full_name')
    : { data: null }
  const people = ((peopleRows ?? []) as { id: string; full_name: string | null }[]).map((u) => ({ id: u.id, name: u.full_name ?? 'Unknown' }))
  const agentFilter = isUuid(sp.agent) && people.some((p) => p.id === sp.agent) ? sp.agent : ''

  // Helper: apply the right scope + filters to a query on a table with a
  // tenant column and a person column (agent_id, from_user_id, sold_by, ...).
  const scope = (q: any, agentCol = 'agent_id', tenantCol = 'tenant_id') => {
    if (isAgentOrCloser) return q.eq(agentCol, myUserId)
    if (!isSuperAdmin) q = q.eq(tenantCol, myTenantId)
    if (companyFilter) q = q.eq(tenantCol, companyFilter)
    if (agentFilter) q = q.eq(agentCol, agentFilter)
    return q
  }

  // --- Build all four queries, then run them IN PARALLEL (one latency hit) ---
  // lead_activity and lead_transfers are confirmed to have created_at (both
  // are selected directly elsewhere in this app), so the date range picker
  // can safely filter them here. sales and client_ownership are NOT
  // filtered by date yet — their schema wasn't confirmed to have a
  // comparable date column. DashboardView flags which metrics are
  // date-scoped vs. all-time so nothing is silently inconsistent.
  // Every page of activities in the range (a single request is capped at
  // 1,000 rows, which used to undercount the disposition breakdown).
  const actQ = readAllPages<{ disposition: string | null }>((from, to, withCount) => {
    let q = supabase.from('lead_activity').select('disposition', withCount ? { count: 'exact' } : undefined)
      .gte('created_at', fromISO).lte('created_at', toISO)
    q = scope(q)
    return q.order('created_at').order('practice_id').order('agent_id').range(from, to)
  }).then((data) => ({ data, count: data.length }))

  // ← ADDED: every email save (Active Email) in the range — lead_email_activity
  // keeps one row per save, like lead_activity does for calls. Same scope and
  // Company / Agent filters. Missing table (email SQL not run) → 0 emails.
  const emailActQ = readAllPages<{ response: string | null }>((from, to, withCount) => {
    let q = supabase.from('lead_email_activity').select('response', withCount ? { count: 'exact' } : undefined)
      .gte('created_at', fromISO).lte('created_at', toISO)
    q = scope(q)
    return q.order('created_at').order('id').range(from, to)
  }).catch((e: { code?: string }) => (['42P01', 'PGRST205'].includes(e?.code ?? '') ? [] : Promise.reject(e)))

  const transQ = scope(supabase.from('lead_transfers').select('id', { count: 'exact', head: true })
    .gte('created_at', fromISO).lte('created_at', toISO), 'from_user_id')

  // ---- Sales in the range (every page; no 1,000-row cut-off) ----
  // Uses each sale's exact creation time when the table has it, otherwise
  // its sale date (a calendar date).
  const missingColumn = (e: any) => ['42703', 'PGRST204'].includes(e?.code) || /column .* does not exist/i.test(e?.message ?? '')
  const salesIn = (col: 'created_at' | 'sale_date') => readAllPages<{ contract_value: number | null; mrr: number | null }>((from, to, first) =>
    scope(supabase.from('sales').select('id, contract_value, mrr', first ? { count: 'exact' } : undefined)
      .gte(col, fromISO).lte(col, toISO), 'sold_by').order('id').range(from, to))
  const salesQ = salesIn('created_at').catch((e) => (missingColumn(e) ? salesIn('sale_date') : Promise.reject(e)))

  // ---- Active clients won in the range (company via owner_tenant_id; agent = who sold it) ----
  const clientByAgent = isAgentOrCloser ? myUserId : agentFilter
  let clientQ = supabase.from('client_ownership')
    .select(clientByAgent ? 'id, sales!inner(sold_by)' : 'id', { count: 'exact', head: true }).eq('active', true)
    .gte('locked_at', fromISO).lte('locked_at', toISO)
  if (!isSuperAdmin) clientQ = clientQ.eq('owner_tenant_id', myTenantId)
  if (companyFilter) clientQ = clientQ.eq('owner_tenant_id', companyFilter)
  if (clientByAgent) clientQ = clientQ.eq('sales.sold_by', clientByAgent)

  // ---- Transfer KPI earned in the range (verified transfers; PKR) ----
  type Credit = { agent_id: string | null; agent_name: string | null; amount: number | null; status?: string | null }
  const creditsIn = (withStatus: boolean) => readAllPages<Credit>((from, to, first) => {
    let q = supabase.from('transfer_kpi_credits')
      .select(withStatus ? 'id, agent_id, agent_name, amount, status' : 'id, agent_id, agent_name, amount', first ? { count: 'exact' } : undefined)
      .gte('verified_at', fromISO).lte('verified_at', toISO)
    if (isAgentOrCloser) q = q.eq('agent_id', myUserId)
    else {
      if (!isSuperAdmin) q = q.eq('tenant_id', myTenantId)
      if (companyFilter) q = q.eq('tenant_id', companyFilter)
      if (agentFilter) q = q.eq('agent_id', agentFilter)
    }
    return q.order('id').range(from, to) as never
  })
  const creditsQ: Promise<Credit[] | null> = creditsIn(true)
    .catch((e) => (missingColumn(e) ? creditsIn(false) : Promise.reject(e)))
    .catch(() => null)   // KPI not set up yet → shown as "not set up", never breaks the page

  const [actRes, transRes, sales, clientRes, credits, emailActs] = await Promise.all([actQ, transQ, salesQ, clientQ, creditsQ, emailActQ]) // ← CHANGED: + emailActs

  const activities = actRes.data
  const activityCount = actRes.count
  const transferCount = transRes.count
  const clientCount = clientRes.count

  // Incentives = verified transfer KPI in the range (rejected ones earn nothing).
  const verifiedCredits = (credits ?? []).filter((c) => (c.status ?? 'verified') !== 'rejected')
  const byAgentMap = new Map<string, { name: string; amount: number; count: number }>()
  for (const c of verifiedCredits) {
    const key = c.agent_id ?? `name:${c.agent_name ?? ''}`
    const row = byAgentMap.get(key) ?? { name: c.agent_name ?? 'Unknown agent', amount: 0, count: 0 }
    row.amount += Number(c.amount) || 0; row.count += 1
    byAgentMap.set(key, row)
  }
  const incentives = credits === null ? null : {
    total: verifiedCredits.reduce((sum, c) => sum + (Number(c.amount) || 0), 0),
    count: verifiedCredits.length,
    byAgent: Array.from(byAgentMap.values()).sort((a, b) => b.amount - a.amount || a.name.localeCompare(b.name)),
  }

  // Disposition breakdown  [REAL]
  const dispoCounts: Record<string, number> = {}
  for (const a of (activities ?? []) as any[]) {
    const d = a.disposition ?? 'none'
    dispoCounts[d] = (dispoCounts[d] ?? 0) + 1
  }

  // ← ADDED: email responses in the range (shown in the Disposition Breakdown)
  const emailResponseCounts: Record<string, number> = {}
  for (const e of emailActs ?? []) {
    const r = (e.response ?? '').trim() || 'No response'
    emailResponseCounts[r] = (emailResponseCounts[r] ?? 0) + 1
  }

  const saleCount = sales?.length ?? 0
  const totalValue = (sales ?? []).reduce((s: number, r: any) => s + (Number(r.contract_value) || 0), 0)
  const totalMrr = (sales ?? []).reduce((s: number, r: any) => s + (Number(r.mrr) || 0), 0)

  // Proposals Shared / Contracts Signed are real counts of logged dispositions
  // (agents can log "Proposal" / "Contract" as a Call Disposition on the Worksheet).
  const proposalsCount = dispoCounts['Proposal'] ?? 0
  const contractsCount = dispoCounts['Contract'] ?? 0

  const companyLabel = companies.find((c) => c.id === companyFilter)?.name
  const agentLabel = people.find((p) => p.id === agentFilter)?.name
  const scopeLabel = (isSuperAdmin || agentFilter) && (companyLabel || agentLabel)
    ? [isSuperAdmin ? 'Platform-wide' : (me as any)?.tenants?.name, companyLabel, agentLabel].filter(Boolean).join(' · ')
    : isSuperAdmin
    ? 'Platform-wide · all companies'
    : isAgentOrCloser
    ? `${(me as any)?.full_name} · personal`
    : `${(me as any)?.tenants?.name} · company`

  const companyName = isSuperAdmin
    ? 'Platform'
    : ((me as any)?.tenants?.name ?? 'Company')

  const roleLabel = canonicalRoleLabel(roleKey)

  // Everything real is passed down; placeholder metrics are flagged in the view.
  return (
    <DashboardView
      scopeLabel={scopeLabel}
      companyName={companyName}
      userName={(me as any)?.full_name ?? 'User'}
      roleLabel={roleLabel}
      activityCount={activityCount ?? 0}
      emailActivityCount={emailActs?.length ?? 0}
      emailResponseCounts={emailResponseCounts}
      transferCount={transferCount ?? 0}
      saleCount={saleCount}
      totalValue={totalValue}
      totalMrr={totalMrr}
      clientCount={clientCount ?? 0}
      incentives={incentives}
      proposalsCount={proposalsCount}
      contractsCount={contractsCount}
      dispoCounts={dispoCounts}
      canManageAssignments={canManageAssignments}
      isSuperAdmin={isSuperAdmin}
      fromDate={fromDate}
      toDate={toDate}
      filters={{ company: companyFilter, agent: agentFilter, companies, people, canPickAgent: !isAgentOrCloser }}
    />
  )
}
