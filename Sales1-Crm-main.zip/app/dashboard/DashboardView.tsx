'use client'

import Link from 'next/link'
import { useMemo } from 'react'
import AppShell from '../AppShell'
import DateRangePicker from './DateRangePicker'
import { SalesFunnel, DispositionDonut } from './Charts'
import TransferKpiPanel from './TransferKpiPanel'
import WorkOverviewPanel from './WorkOverviewPanel'

type Props = {
  scopeLabel: string
  companyName: string
  userName: string
  roleLabel: string
  /** Call activities logged in range (lead_activity). */
  activityCount: number
  /** ← ADDED: email saves in range (lead_email_activity) + their responses. */
  emailActivityCount?: number
  emailResponseCounts?: Record<string, number>
  transferCount: number
  saleCount: number
  totalValue: number
  totalMrr: number
  clientCount: number
  /** Verified Transfer KPI (PKR) in the range; null when the KPI isn't set up. */
  incentives?: { total: number; count: number; byAgent: { name: string; amount: number; count: number }[] } | null
  proposalsCount: number
  contractsCount: number
  dispoCounts: Record<string, number>
  canManageAssignments?: boolean
  isSuperAdmin?: boolean
  fromDate: string
  toDate: string
  /** Dashboard-wide Company / Agent filters (applied to every number). */
  filters?: import('./DateRangePicker').DashboardFilterOptions
}

const money = (n: number) => '$' + (Number(n) || 0).toLocaleString()

export default function DashboardView(p: Props) {
  // ← ADDED: "activities" = calls + emails, so an email agent's work counts.
  const emailCount = p.emailActivityCount ?? 0
  const totalActivities = p.activityCount + emailCount

  // ---- REAL funnel: activities -> transfers -> sales ----
  const funnel = useMemo(() => {
    const worked = totalActivities // ← CHANGED: calls + emails
    const rows = [
      { label: 'Activities logged', value: worked, colorVar: 'var(--accent)' },
      { label: 'Transfers', value: p.transferCount, colorVar: '#22d3ee' },
      { label: 'Sales', value: p.saleCount, colorVar: 'var(--purple)' },
    ]
    const top = Math.max(worked, 1)
    return rows.map((r) => ({ ...r, pct: Math.round((r.value / top) * 100) }))
  }, [totalActivities, p.transferCount, p.saleCount])

  // ← CHANGED: email responses join the breakdown, labelled "Email · <response>"
  // so they never mix with a call disposition of the same name.
  const dispoRows = useMemo(
    () => [
      ...Object.entries(p.dispoCounts),
      ...Object.entries(p.emailResponseCounts ?? {}).map(([r, n]) => [`Email · ${r}`, n] as [string, number]),
    ].sort((a, b) => b[1] - a[1]),
    [p.dispoCounts, p.emailResponseCounts]
  )

  const currentUser = { full_name: p.userName, role: p.roleLabel, company: p.companyName }

  return (
    <AppShell
      title="Performance Dashboard"
      subtitle={`Sales & KPI overview · Scope: ${p.scopeLabel}`}
      currentUser={currentUser}
      active="/dashboard"
      showAdmin={!!p.isSuperAdmin}
      showTransfers
      canManageUsers={!!p.isSuperAdmin || !!p.canManageAssignments}
      headerRight={p.canManageAssignments ? (
        <Link prefetch={false} href="/assignments" className="btn btn-primary" style={{ textDecoration: 'none' }}>
          Manage assigned leads
        </Link>
      ) : null}
    >
      <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
        {/* ---- Date & time range: in the page (not the top bar), above the numbers ---- */}
        <DateRangePicker from={p.fromDate} to={p.toDate} filters={p.filters} />

        {/* ---- Hero stats: the headline numbers, given real visual weight
             instead of sitting equal-sized next to nine other cards ---- */}
        <div className="hero-stats-row page-anchor" id="overview">
          <HeroStat label="Total Contract Value" value={money(p.totalValue)} sub="Sales closed, in range" accent="var(--accent)" />
          <div className="hero-stats-divider" />
          {/* ← CHANGED: includes email work; the split is shown when there is any */}
          <HeroStat label="Activities Logged" value={totalActivities}
            sub={emailCount ? `Calls ${p.activityCount.toLocaleString()} · Emails ${emailCount.toLocaleString()}, in range` : 'Outbound dialing activity, in range'}
            accent="var(--c-calls)" />
          <div className="hero-stats-divider" />
          <HeroStat label="Closed Sales" value={p.saleCount} sub="Sales closed, in range" accent="var(--c-sales)" />
        </div>

        {/* ---- Secondary KPI cards — everything else, at a smaller, supporting weight ---- */}
        <div className="kpi-cards-grid kpi-cards-grid-secondary">
          <Kpi label="Transfers" value={p.transferCount} sub="Qualified lead handovers, in range" color="transfers" icon={<IconTransfer />} />
          <Kpi label="Active Clients" value={p.clientCount} sub="Won in range and still active" color="collected" icon={<IconUsers />} />
          <Kpi label="Proposals Shared" value={p.proposalsCount} sub="Standard pitches delivered, in range" color="proposals" icon={<IconFileText />} />
          <Kpi label="Contracts Signed" value={p.contractsCount} sub="Pending closes signed, in range" color="contracts" icon={<IconFileCheck />} />
        </div>

        {/* ---- Worksheets, transfers and Call Disposition breakdown (follows the date range) ---- */}
        <WorkOverviewPanel fromDate={p.fromDate} toDate={p.toDate} companyId={p.filters?.company ?? ''} agentId={p.filters?.agent ?? ''} />

        {/* ---- Transfer KPI: PKR 500 per verified transfer (this month + all-time) ---- */}
        <TransferKpiPanel companyId={p.filters?.company ?? ''} agentId={p.filters?.agent ?? ''} />

        {/* ---- Charts row ---- */}
        <div className="grid-dash-a page-anchor" id="pipeline">
          {/* Conversion funnel (REAL) */}
          <Panel title="Conversion funnel" subtitle="Activities → transfers → sales">
            <SalesFunnel rows={funnel} />
          </Panel>

          <Panel title="Disposition Breakdown" subtitle="Outcomes logged in scope">
            <DispositionDonut rows={dispoRows} />
          </Panel>
        </div>

        <div className="kpi-cards-grid kpi-cards-grid-secondary dashboard-secondary page-anchor" id="revenue">
          <Kpi label="Total MRR" value={money(p.totalMrr)} sub="Monthly revenue of sales closed in range" color="calls" icon={<IconTrendingUp />} />
          <Kpi label="Total Incentives Earned" value={p.incentives ? pkr(p.incentives.total) : '—'}
            sub={p.incentives ? `Transfer KPI · ${p.incentives.count} verified transfer${p.incentives.count === 1 ? '' : 's'} in range` : 'Transfer KPI is not set up yet'}
            color="incentives" icon={<IconWallet />} />
        </div>

        {/* ---- Ratios + incentive splits ---- */}
        <div className="grid-dash-b page-anchor" id="conversion">
          {/* Conversion ratios (REAL from funnel) */}
          <Panel title="Conversion ratios" subtitle="Lead progression efficiency">
            {[
              ['Activity → transfer', totalActivities ? Math.round((p.transferCount / totalActivities) * 100) : 0], // ← CHANGED
              ['Transfer → sale', p.transferCount ? Math.round((p.saleCount / p.transferCount) * 100) : 0],
              ['Sale → client', p.saleCount ? Math.round((p.clientCount / p.saleCount) * 100) : 0],
            ].map(([label, pct]) => (
              <div key={label as string} style={{ marginTop: 14 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 6 }}>
                  <span className="subtle">{label}</span>
                  <span style={{ color: 'var(--purple)' }}>{pct}%</span>
                </div>
                <div style={{ height: 6, borderRadius: 3, background: 'var(--surface-2)' }}>
                  <div style={{ width: `${pct}%`, height: '100%', background: 'var(--purple)', borderRadius: 3 }} />
                </div>
              </div>
            ))}
          </Panel>

          {/* Incentives by agent (REAL: verified Transfer KPI in the range) */}
          <Panel title="Incentives by agent" subtitle="Transfer KPI earned in range (PKR)">
            {!p.incentives ? (
              <p className="subtle" style={{ marginTop: 10, fontSize: 12 }}>Transfer KPI is not set up yet.</p>
            ) : p.incentives.byAgent.length === 0 ? (
              <p className="subtle" style={{ marginTop: 10, fontSize: 12 }}>No verified transfers in this range.</p>
            ) : (
              <div style={{ display: 'flex', alignItems: 'center', gap: 20, marginTop: 8, flexWrap: 'wrap' }}>
                <Donut parts={splitParts(p.incentives.byAgent)} />
                <div style={{ display: 'flex', flexDirection: 'column', gap: 8, fontSize: 12, minWidth: 0, flex: 1 }}>
                  {splitParts(p.incentives.byAgent).map((part) => (
                    <div key={part.label} style={{ display: 'flex', alignItems: 'center', gap: 8 }} className="subtle">
                      <span style={{ width: 10, height: 10, borderRadius: 2, background: part.color, display: 'inline-block', flex: 'none' }} />
                      <span style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{part.label}</span>
                      <strong style={{ color: 'var(--ink-strong)' }}>{pkr(part.value)}</strong>
                      <span>· {part.count}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </Panel>
        </div>

      </div>
    </AppShell>
  )
}

function HeroStat({ label, value, sub, accent }: { label: string; value: number | string; sub: string; accent: string }) {
  return (
    <div className="hero-stat">
      <div className="hero-stat-value" style={{ color: accent }}>{value}</div>
      <div className="hero-stat-label">{label}</div>
      <div className="hero-stat-sub">{sub}</div>
    </div>
  )
}

type KpiColor = 'calls' | 'transfers' | 'contracts' | 'sales' | 'proposals' | 'incentives' | 'collected' | 'outstanding'

function Kpi({ label, value, sub, color, icon, sample }: {
  label: string; value: number | string; sub: string; color: KpiColor; icon: React.ReactNode; sample?: boolean
}) {
  const varColor = `var(--c-${color})`
  const rgbVar = `var(--c-${color}-rgb)`
  return (
    <div className="kpi-card">
      <div className="kpi-card-stripe" style={{ background: varColor }} />
      {sample && <span className="kpi-card-sample">sample</span>}
      <div className="kpi-card-top">
        <div className="kpi-card-text">
          <div className="kpi-card-label">{label}</div>
          <div className="kpi-card-value">{value}</div>
          <div className="kpi-card-sub">{sub}</div>
        </div>
        <div className="kpi-card-icon" style={{ background: `rgba(${rgbVar},0.1)`, borderColor: `rgba(${rgbVar},0.28)`, color: varColor }}>
          {icon}
        </div>
      </div>
    </div>
  )
}

// ---- Small hand-authored icon set (stroke-based, matches lucide's visual style) ----
const iconProps = {
  viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 2,
  strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const,
  'aria-hidden': true, focusable: false,
}
function IconTransfer() {
  return <svg {...iconProps}><path d="m16 3 4 4-4 4" /><path d="M20 7H4" /><path d="m8 21-4-4 4-4" /><path d="M4 17h16" /></svg>
}
function IconUsers() {
  return <svg {...iconProps}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>
}
function IconFileText() {
  return <svg {...iconProps}><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" /><path d="M14 2v4a2 2 0 0 0 2 2h4" /><path d="M10 9H8" /><path d="M16 13H8" /><path d="M16 17H8" /></svg>
}
function IconFileCheck() {
  return <svg {...iconProps}><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" /><path d="M14 2v4a2 2 0 0 0 2 2h4" /><path d="m9 15 2 2 4-4" /></svg>
}
function IconTrendingUp() {
  return <svg {...iconProps}><path d="M16 7h6v6" /><path d="m22 7-8.5 8.5-5-5L2 17" /></svg>
}
function IconWallet() {
  return <svg {...iconProps}><path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4" /><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4" /><path d="M18 12a2 2 0 0 0 0 4h4v-4Z" /></svg>
}

function Panel({ title, subtitle, sample, children }: { title: string; subtitle?: string; sample?: boolean; children: React.ReactNode }) {
  return (
    <section className="card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <h2 style={{ fontSize: 15, fontWeight: 700, margin: 0, color: 'var(--ink-strong)' }}>{title}</h2>
          {subtitle && <div className="subtle" style={{ marginTop: 3 }}>{subtitle}</div>}
        </div>
        {sample && <span style={{ fontSize: 9, color: 'var(--muted)', border: '1px solid var(--border)', borderRadius: 4, padding: '1px 5px' }}>sample</span>}
      </div>
      {children}
    </section>
  )
}

const pkr = (n: number) => `PKR ${Math.round(n).toLocaleString()}`
const SPLIT_COLORS = ['var(--accent)', 'var(--purple)', '#22d3ee', 'var(--warn)', 'var(--ok)', '#f472b6']

/** Top 5 agents by PKR, the rest grouped as "Others". */
function splitParts(byAgent: { name: string; amount: number; count: number }[]) {
  const top = byAgent.slice(0, 5)
  const rest = byAgent.slice(5)
  const parts = top.map((a, i) => ({ label: a.name, value: a.amount, count: a.count, color: SPLIT_COLORS[i] }))
  if (rest.length) parts.push({ label: `Others (${rest.length})`, value: rest.reduce((s, a) => s + a.amount, 0), count: rest.reduce((s, a) => s + a.count, 0), color: SPLIT_COLORS[5] })
  return parts
}

/** Real donut: one segment per part, sized by its share of the total. */
function Donut({ parts }: { parts: { label: string; value: number; color: string }[] }) {
  const total = parts.reduce((s, p) => s + p.value, 0)
  const circumference = 2 * Math.PI * 44
  let offset = 0
  return (
    <svg aria-hidden="true" focusable="false" width="120" height="120" viewBox="0 0 120 120">
      <circle cx="60" cy="60" r="44" fill="none" stroke="var(--surface-2)" strokeWidth="16" />
      {total > 0 && parts.map((part) => {
        const length = (part.value / total) * circumference
        const el = (
          <circle key={part.label} cx="60" cy="60" r="44" fill="none" stroke={part.color} strokeWidth="16"
            strokeDasharray={`${length} ${circumference - length}`} strokeDashoffset={-offset} transform="rotate(-90 60 60)" />
        )
        offset += length
        return el
      })}
    </svg>
  )
}
