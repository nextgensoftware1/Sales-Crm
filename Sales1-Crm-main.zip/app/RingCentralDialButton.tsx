'use client'

import { useEffect, useRef, useState } from 'react'
import { PhoneCall } from 'lucide-react'

function toE164(value: string): string | null {
  const digits = value.replace(/\D/g, '')
  if (digits.length < 7 || digits.length > 15) return null
  return digits.length === 10 ? `+1${digits}` : digits.length === 11 && digits.startsWith('1') ? `+${digits}` : `+${digits}`
}

export default function RingCentralDialButton({
  phoneNumber,
  className,
  children,
}: {
  phoneNumber: string | null | undefined
  className?: string
  children?: React.ReactNode
}) {
  const [busy, setBusy] = useState(false)
  const [message, setMessage] = useState('')
  const [fallbackPhone, setFallbackPhone] = useState<string | null>(null)
  const callLock = useRef(false)
  const [employeeLoggedIn, setEmployeeLoggedIn] = useState(false)
  const [hasOutboundPermission, setHasOutboundPermission] = useState<boolean | undefined>(undefined)

  useEffect(() => {
    setEmployeeLoggedIn(window.__ringCentralEmployeeStatus?.loggedIn === true)
    setHasOutboundPermission(window.__ringCentralEmployeeStatus?.hasOutboundPermission)
    const handleEmployeeStatus = (event: Event) => {
      const detail = (event as CustomEvent<{
        loggedIn?: boolean
        hasOutboundPermission?: boolean
      }>).detail
      if (typeof detail.loggedIn === 'boolean') setEmployeeLoggedIn(detail.loggedIn)
      if (typeof detail.hasOutboundPermission === 'boolean') setHasOutboundPermission(detail.hasOutboundPermission)
    }
    const handleCallStatus = (event: Event) => {
      const detail = (event as CustomEvent<{ status?: string }>).detail
      if (!detail.status) return
      setMessage(detail.status)
      if (detail.status === 'Call ended' || detail.status === 'Call failed') {
        callLock.current = false
        setBusy(false)
      }
    }
    window.addEventListener('ringcentral-employee-status', handleEmployeeStatus)
    window.addEventListener('ringcentral-call-status', handleCallStatus)
    return () => {
      window.removeEventListener('ringcentral-employee-status', handleEmployeeStatus)
      window.removeEventListener('ringcentral-call-status', handleCallStatus)
    }
  }, [])

  const dial = () => {
    if (!phoneNumber || callLock.current) return
    const e164 = toE164(phoneNumber)
    if (!e164) {
      setMessage('Call failed: enter a valid destination phone number.')
      return
    }

    setFallbackPhone(e164)
    const adapter = window.RCAdapter
    if (!adapter || typeof adapter.clickToCall !== 'function') {
      setMessage('Call failed: RingCentral Embeddable is not ready. Use RingOut fallback.')
      return
    }
    if (!employeeLoggedIn) {
      setMessage('Call failed: sign in to your own RingCentral account in the embedded widget.')
      return
    }
    if (hasOutboundPermission === false) {
      setMessage('Call failed: your RingCentral account has no verified outbound calling configuration.')
      return
    }

    callLock.current = true
    setBusy(true)
    setMessage(`Calling ${e164}`)
    try {
      adapter.clickToCall(e164, true)
    } catch {
      callLock.current = false
      setBusy(false)
      setMessage(`Call failed: RingCentral could not start the call to ${e164}.`)
    }
  }

  const ringOutFallback = async () => {
    if (!fallbackPhone || callLock.current) return
    callLock.current = true
    setBusy(true)
    setMessage(`Calling ${fallbackPhone} through RingOut fallback`)
    try {
      const response = await fetch('/api/ringcentral/dial', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        cache: 'no-store',
        body: JSON.stringify({ phoneNumber: fallbackPhone }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) {
        setMessage(`Call failed: ${data.message || 'RingOut could not start the call.'}`)
      } else {
        setMessage(`Calling ${fallbackPhone} through RingOut fallback`)
      }
    } catch {
      setMessage(`Call failed: could not reach RingOut for ${fallbackPhone}`)
    } finally {
      window.setTimeout(() => {
        callLock.current = false
        setBusy(false)
      }, 1500)
    }
  }

  if (!phoneNumber?.trim()) return <>{children ?? '—'}</>

  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, maxWidth: '100%' }}>
      <button
        type="button"
        className={className}
        onClick={dial}
        disabled={busy}
        title={`Call ${phoneNumber} with RingCentral`}
        aria-label={`Call ${phoneNumber} with RingCentral`}
        style={{
          appearance: 'none',
          border: 0,
          background: 'transparent',
          color: 'inherit',
          padding: 0,
          margin: 0,
          display: 'inline-flex',
          alignItems: 'center',
          gap: 6,
          font: 'inherit',
          minWidth: 0,
          textAlign: 'left',
        }}
      >
        <PhoneCall size={14} aria-hidden="true" />
        <span style={{ overflowWrap: 'anywhere' }}>{children ?? phoneNumber}</span>
      </button>
      {message && <span role="status" style={{ fontSize: 11, color: message.startsWith('Call failed') ? 'var(--danger)' : 'var(--ok)' }}>{message}</span>}
      {fallbackPhone && (
        <button
          type="button"
          onClick={() => void ringOutFallback()}
          disabled={busy}
          style={{ border: 0, background: 'transparent', padding: 0, font: 'inherit', fontSize: 11, textDecoration: 'underline', cursor: busy ? 'default' : 'pointer' }}
          title="Manual legacy fallback. Do not use together with Embeddable."
        >
          RingOut fallback
        </button>
      )}
    </span>
  )
}
