'use client'

import { useEffect, useState } from 'react'

const ADAPTER_SCRIPT_ID = 'ringcentral-embeddable-adapter'
const ADAPTER_SCRIPT_URL = 'https://apps.ringcentral.com/integration/ringcentral-embeddable/latest/adapter.js'
const EMBEDDABLE_ORIGIN = 'https://apps.ringcentral.com'

declare global {
  interface Window {
    RC_EMBEDDABLE_ADAPTER_MANUAL_INIT?: boolean
    RCAdapter?: {
      clickToCall: (phoneNumber: string, toCall?: boolean) => unknown
      dispose?: () => void
    }
    RCAdapterInit?: () => void
    RCAdapterDisposed?: boolean
    __ringCentralEmployeeStatus?: {
      loggedIn?: boolean
      webPhoneConnected?: boolean
      loginNumber?: string
      callWith?: string
      hasOutboundPermission?: boolean
    }
  }
}

export type RingCentralEmployeeStatus = {
  adapterReady: boolean
  loggedIn: boolean
  loginNumber?: string
  webPhoneConnected: boolean
  callStatus: string
}

function postToEmbeddable(type: string) {
  const frame = document.querySelector<HTMLIFrameElement>('#rc-widget-adapter-frame')
  if (!frame?.contentWindow) return false
  frame.contentWindow.postMessage({ type }, EMBEDDABLE_ORIGIN)
  return true
}

export default function RingCentralEmbeddable() {
  const [status, setStatus] = useState<RingCentralEmployeeStatus>({
    adapterReady: false,
    loggedIn: false,
    webPhoneConnected: false,
    callStatus: 'Initializing RingCentral...',
  })

  useEffect(() => {
    window.RC_EMBEDDABLE_ADAPTER_MANUAL_INIT = true

    const handleMessage = (event: MessageEvent) => {
      if (event.origin !== EMBEDDABLE_ORIGIN) return
      const data = event.data
      if (!data || typeof data !== 'object' || typeof data.type !== 'string') return

      if (data.type === 'rc-login-status-notify') {
        const loggedIn = data.loggedIn === true
        window.__ringCentralEmployeeStatus = {
          ...window.__ringCentralEmployeeStatus,
          loggedIn,
          webPhoneConnected: window.__ringCentralEmployeeStatus?.webPhoneConnected ?? false,
          loginNumber: typeof data.loginNumber === 'string' ? data.loginNumber : undefined,
        }
        setStatus((current) => ({
          ...current,
          loggedIn,
          loginNumber: typeof data.loginNumber === 'string' ? data.loginNumber : undefined,
          callStatus: loggedIn ? 'RingCentral signed in' : 'Sign in to your RingCentral account',
        }))
        window.dispatchEvent(new CustomEvent('ringcentral-employee-status', {
          detail: { loggedIn, loginNumber: typeof data.loginNumber === 'string' ? data.loginNumber : undefined },
        }))
      } else if (data.type === 'rc-webphone-connection-status-notify') {
        const connected = data.connectionStatus === 'connectionStatus-connected'
        window.__ringCentralEmployeeStatus = {
          ...window.__ringCentralEmployeeStatus,
          webPhoneConnected: connected,
          loggedIn: window.__ringCentralEmployeeStatus?.loggedIn ?? false,
        }
        setStatus((current) => ({
          ...current,
          webPhoneConnected: connected,
          callStatus: connected ? 'RingCentral phone connected' : 'RingCentral phone disconnected',
        }))
        window.dispatchEvent(new CustomEvent('ringcentral-employee-status', {
          detail: { webPhoneConnected: connected },
        }))
      } else if (data.type === 'rc-calling-settings-notify') {
        const callWith = typeof data.callWith === 'string' ? data.callWith : undefined
        const fromNumbers = Array.isArray(data.fromNumbers) ? data.fromNumbers : []
        const hasOutboundPermission = Boolean(callWith || fromNumbers.length > 0)
        window.__ringCentralEmployeeStatus = {
          ...window.__ringCentralEmployeeStatus,
          loggedIn: window.__ringCentralEmployeeStatus?.loggedIn ?? false,
          webPhoneConnected: window.__ringCentralEmployeeStatus?.webPhoneConnected ?? false,
          callWith,
          hasOutboundPermission,
        }
        window.dispatchEvent(new CustomEvent('ringcentral-employee-status', {
          detail: { callWith, hasOutboundPermission },
        }))
      } else if (data.type === 'rc-call-init-notify') {
        setStatus((current) => ({ ...current, callStatus: 'Calling...' }))
        window.dispatchEvent(new CustomEvent('ringcentral-call-status', { detail: { status: 'Calling' } }))
      } else if (data.type === 'rc-call-start-notify') {
        setStatus((current) => ({ ...current, callStatus: 'Call started' }))
        window.dispatchEvent(new CustomEvent('ringcentral-call-status', { detail: { status: 'Call started' } }))
      } else if (data.type === 'rc-call-end-notify') {
        setStatus((current) => ({ ...current, callStatus: 'Call ended' }))
        window.dispatchEvent(new CustomEvent('ringcentral-call-status', { detail: { status: 'Call ended' } }))
      } else if (data.type === 'rc-adapter-error') {
        setStatus((current) => ({ ...current, callStatus: 'Call failed or permission unavailable' }))
      }
    }

    window.addEventListener('message', handleMessage)

    const initialize = () => {
      if (!window.RCAdapter && typeof window.RCAdapterInit === 'function') {
        window.RCAdapterInit()
      }
      setStatus((current) => ({
        ...current,
        adapterReady: typeof window.RCAdapter?.clickToCall === 'function',
        callStatus: typeof window.RCAdapter?.clickToCall === 'function'
          ? 'RingCentral adapter ready'
          : 'RingCentral adapter unavailable',
      }))
    }

    let script = document.getElementById(ADAPTER_SCRIPT_ID) as HTMLScriptElement | null
    if (!script) {
      script = document.createElement('script')
      script.id = ADAPTER_SCRIPT_ID
      script.src = ADAPTER_SCRIPT_URL
      script.async = true
      script.onload = initialize
      document.body.appendChild(script)
    } else if (window.RCAdapter || typeof window.RCAdapterInit === 'function') {
      initialize()
    } else {
      script.addEventListener('load', initialize, { once: true })
    }

    return () => window.removeEventListener('message', handleMessage)
  }, [])

  const signIn = () => {
    if (!postToEmbeddable('rc-adapter-login')) {
      setStatus((current) => ({ ...current, callStatus: 'RingCentral login interface unavailable' }))
      return
    }
    setStatus((current) => ({ ...current, callStatus: 'Opening RingCentral sign-in' }))
  }

  return (
    <div
      role="status"
      aria-live="polite"
      style={{
        position: 'fixed',
        left: 12,
        bottom: 12,
        zIndex: 1000,
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        maxWidth: 340,
        padding: '7px 10px',
        border: '1px solid var(--line, #d5d9e2)',
        borderRadius: 8,
        background: 'var(--surface, #fff)',
        color: 'var(--ink, #222)',
        fontSize: 12,
        boxShadow: '0 4px 18px rgba(0,0,0,.12)',
      }}
    >
      <span style={{ minWidth: 0 }}>{status.callStatus}</span>
      {!status.loggedIn && (
        <button type="button" onClick={signIn} style={{ flexShrink: 0 }}>
          Sign in
        </button>
      )}
    </div>
  )
}
